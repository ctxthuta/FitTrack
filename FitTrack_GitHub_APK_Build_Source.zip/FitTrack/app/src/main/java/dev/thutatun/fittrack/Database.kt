package dev.thutatun.fittrack

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="checks", primaryKeys=["day", "task"])
data class CheckEntity(val day:String, val task:String, val done:Boolean=false)
@Entity(tableName="weights")
data class WeightEntity(@PrimaryKey val day:String, val kg:Double, val synced:Boolean=false)
@Entity(tableName="walks")
data class WalkEntity(@PrimaryKey val day:String, val km:Double=0.0, val steps:Long=0L, val source:String="manual")
@Entity(tableName="meals")
data class MealEntity(@PrimaryKey(autoGenerate=true) val id:Long=0, val day:String, val name:String, val kcal:Int, val protein:Double=0.0, val photoUri:String="", val status:String="confirmed")
@Entity(tableName="water")
data class WaterEntity(@PrimaryKey val day:String, val glasses:Int=0)
@Dao interface FitDao {
    @Query("SELECT * FROM checks WHERE day=:day") fun checks(day:String):Flow<List<CheckEntity>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putCheck(item:CheckEntity)
    @Query("SELECT * FROM checks WHERE day=:day AND task=:task LIMIT 1") suspend fun getCheck(day:String,task:String):CheckEntity?
    @Query("SELECT * FROM checks") fun allChecks():Flow<List<CheckEntity>>
    @Query("SELECT * FROM weights ORDER BY day DESC") fun weights():Flow<List<WeightEntity>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putWeight(item:WeightEntity)
    @Query("SELECT * FROM walks WHERE day=:day LIMIT 1") fun walk(day:String):Flow<WalkEntity?>
    @Query("SELECT * FROM walks WHERE day=:day LIMIT 1") suspend fun getWalk(day:String):WalkEntity?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putWalk(item:WalkEntity)
    @Query("SELECT * FROM meals WHERE day=:day ORDER BY id DESC") fun meals(day:String):Flow<List<MealEntity>>
    @Insert suspend fun putMeal(item:MealEntity)
    @Query("SELECT * FROM water WHERE day=:day LIMIT 1") fun water(day:String):Flow<WaterEntity?>
    @Query("SELECT * FROM water WHERE day=:day LIMIT 1") suspend fun getWater(day:String):WaterEntity?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putWater(item:WaterEntity)
}
@Database(entities=[CheckEntity::class,WeightEntity::class,WalkEntity::class,MealEntity::class,WaterEntity::class],version=1,exportSchema=false)
abstract class FitDatabase:RoomDatabase() {
    abstract fun dao():FitDao
    companion object {
        @Volatile private var instance:FitDatabase?=null
        fun get(context:Context):FitDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext,FitDatabase::class.java,"fittrack.db").build().also { instance=it }
        }
    }
}
