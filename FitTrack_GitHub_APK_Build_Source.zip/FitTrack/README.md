# FitTrack Android (source MVP)

Native Android fitness tracker built with Kotlin, Jetpack Compose, Room/SQLite, WorkManager, Health Connect, and Gemini 2.5 Flash.

## Download and build

This archive contains Android Studio source code, **not an APK**. Open the project folder in Android Studio with JDK 17 and Android SDK 35, allow Gradle to sync, then select **Build > Build APK(s)**. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`. Transfer the APK to your phone and install it. Android Studio/Gradle and an Android SDK are required. The build was not run in this environment.

## Included

- Daily checklist based on the established schedule: 4 km walking daily; 5 app exercises Sunday, Tuesday, Thursday; Sunday weigh-in; meal and water tracking.
- Daily calendar date navigation, checklist completion and streak calculation.
- Weight logs, recent history, daily food calories/protein and activity summary.
- Manual steps/distance and Health Connect steps/distance import. Import **replaces** the daily record instead of summing it to avoid duplicate counting.
- Health Connect weight export with a stable client record ID; per-day SQLite upsert prevents duplicate local weight records.
- Photo picker and Gemini meal estimation with user confirmation/edit before saving. Food image is transmitted to Gemini only when chosen.
- Gemini key encrypted at rest with Android Keystore; no API key in source code.
- Local notifications for workout/walking, water and meal logging. Notifications include Done and Snooze 5 min. Unchecked tasks re-notify through WorkManager, within 08:00–21:00.
- Local-first SQLite records and missed-day browsing. Most features work offline; Gemini requires connectivity.

## Important limitations

This is a **functional source MVP**, not a finished production app. It has not been compiled or tested on a physical phone here. The theme is a blue/white approximation of the supplied screenshot, not a verified reproduction of thutatun.dev.

- Android WorkManager is inexact. Five-minute snoozes are best-effort and might run later due to Doze/battery optimization. Exact 5-minute alarms would require a separate exact-alarm implementation and policy/permission handling.
- Reminders are scheduled by a 15-minute periodic background check and follow-up one-time work. Daytime water prompts are targeted for even hours but Android scheduling can delay them.
- Photo analysis is online only. Failed/offline Gemini requests are not queued for retry. Other entries persist locally offline.
- Health Connect is Android's on-device health-data exchange. It is **not** automatic Google Fit cloud sync. This MVP reads steps and distance and writes weight; it does not sync all SQLite entities, import weight, or reconcile edits/deletes bidirectionally.
- A full month-grid calendar, graph charts, step sensor live counting, waist/progress photos, configurable reminders, encrypted backup, data export and production-ready sync conflict handling are not yet implemented.
- Android's photo picker URI is stored for reference; it is not copied into durable app-private storage.
- Food calorie estimation from images is approximate. Check portions, ingredients and cooking oils before saving.
- Android backup is currently enabled. For privacy-sensitive use, configure backup rules before distribution.

## Permissions

- POST_NOTIFICATIONS: reminders on Android 13+
- ACTIVITY_RECOGNITION: optional future sensor features
- Health Connect permissions: steps/distance/weight access. Approve through the Activity screen.
- INTERNET: Gemini image analysis

## Build dependencies

AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, Room 2.6.1, WorkManager 2.10.0, Health Connect 1.1.0-alpha11, OkHttp 4.12.0.

## Security

For personal use, a user-supplied Gemini key is encrypted with Android Keystore. For a publicly distributed app, route Gemini through an authenticated backend proxy and enforce per-user quotas. Avoid committing API keys to Git.

## Build APK without Android Studio (GitHub Actions)

1. Upload the contents of this project folder into a GitHub repository (the `.github` directory must be included).
2. In the repository, open **Actions** > **Build FitTrack Android APK** > **Run workflow**.
3. If the build succeeds, open the workflow run and download the **FitTrack-debug-apk** artifact.
4. Extract `app-debug.apk` from the downloaded artifact ZIP on Android, then install it (allow installs from the browser/files app when prompted).

The workflow is supplied but has **not been executed or validated** here. The source may require compile fixes. The debug APK is for personal testing, not Play Store distribution. Never commit your Gemini API key.
