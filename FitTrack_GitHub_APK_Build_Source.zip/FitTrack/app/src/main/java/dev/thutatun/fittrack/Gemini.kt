package dev.thutatun.fittrack

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SecretStore {
    private const val alias="fittrack_gemini_key"
    private fun secret():SecretKey {
        val store=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias,null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance("AES","AndroidKeyStore").apply {
            init(android.security.keystore.KeyGenParameterSpec.Builder(alias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes("GCM").setEncryptionPaddings("NoPadding").build())
        }.generateKey()
    }
    fun save(context:Context,value:String) {
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE,secret()) }
        val bytes=cipher.iv+cipher.doFinal(value.toByteArray())
        context.getSharedPreferences("secrets",Context.MODE_PRIVATE).edit().putString("key",Base64.encodeToString(bytes,Base64.NO_WRAP)).apply()
    }
    fun get(context:Context):String? = try {
        val raw=context.getSharedPreferences("secrets",Context.MODE_PRIVATE).getString("key",null)?:return null
        val bytes=Base64.decode(raw,Base64.NO_WRAP)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE,secret(),GCMParameterSpec(128,bytes.copyOfRange(0,12))) }
        String(cipher.doFinal(bytes.copyOfRange(12,bytes.size)))
    } catch(_:Exception) { null }
}
data class FoodEstimate(val name:String,val kcal:Int,val protein:Double,val note:String)
object Gemini {
    private val http=OkHttpClient.Builder().callTimeout(java.time.Duration.ofSeconds(45)).build()
    suspend fun estimate(context:Context,bytes:ByteArray):FoodEstimate=withContext(Dispatchers.IO) {
        val key=SecretStore.get(context)?:error("Add your Gemini API key in Settings")
        val prompt="Estimate this meal's total calories and protein. Include sauces and oil where visible. Respond ONLY JSON: {\"name\":\"meal description\",\"kcal\":integer,\"protein\":number,\"note\":\"uncertainty and assumptions\"}. This is an approximate estimate, not a measurement."
        val image=JSONObject().put("mime_type","image/jpeg").put("data",Base64.encodeToString(bytes,Base64.NO_WRAP))
        val parts=org.json.JSONArray().put(JSONObject().put("text",prompt)).put(JSONObject().put("inline_data",image))
        val payload=JSONObject().put("contents",org.json.JSONArray().put(JSONObject().put("parts",parts)))
            .put("generationConfig",JSONObject().put("responseMimeType","application/json"))
        val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")
            .header("x-goog-api-key",key).post(payload.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { response ->
            val body=response.body?.string().orEmpty()
            if(!response.isSuccessful) error("Gemini request failed (${response.code}): ${body.take(180)}")
            val text=JSONObject(body).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val json=JSONObject(text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
            FoodEstimate(json.optString("name","Meal"),json.optInt("kcal",0),json.optDouble("protein",0.0),json.optString("note","Approximate estimate"))
        }
    }
}
