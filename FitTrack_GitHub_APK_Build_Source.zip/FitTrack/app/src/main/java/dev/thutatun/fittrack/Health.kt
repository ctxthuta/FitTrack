package dev.thutatun.fittrack

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.health.connect.client.units.Mass
import java.time.LocalDate
import java.time.ZoneId
import java.time.Instant

object Health {
    val permissions=setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getWritePermission(WeightRecord::class)
    )
    fun available(context:Context)=HealthConnectClient.getSdkStatus(context)==HealthConnectClient.SDK_AVAILABLE
    suspend fun readDay(context:Context,day:LocalDate):Pair<Long,Double> {
        val client=HealthConnectClient.getOrCreate(context)
        val start=day.atStartOfDay(ZoneId.systemDefault()).toInstant()
        val end=day.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant()
        val result=client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL,DistanceRecord.DISTANCE_TOTAL),TimeRangeFilter.between(start,end)))
        return Pair(result[StepsRecord.COUNT_TOTAL]?:0L,(result[DistanceRecord.DISTANCE_TOTAL]?.inMeters?:0.0)/1000.0)
    }
    suspend fun writeWeight(context:Context,day:LocalDate,kg:Double) {
        val client=HealthConnectClient.getOrCreate(context)
        val timestamp=day.atTime(9,0).atZone(ZoneId.systemDefault()).toInstant()
        // Client record ID prevents duplicate writes across retries.
        val record=WeightRecord(time=timestamp,zoneOffset=ZoneId.systemDefault().rules.getOffset(timestamp),weight=Mass.kilograms(kg),metadata=androidx.health.connect.client.records.metadata.Metadata.manualEntry(clientRecordId="fittrack-weight-$day",clientRecordVersion=1))
        client.insertRecords(listOf(record))
    }
}
