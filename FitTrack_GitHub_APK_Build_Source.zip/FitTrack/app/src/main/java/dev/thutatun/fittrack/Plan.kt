package dev.thutatun.fittrack

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object Plan {
    const val kcalGoal=1900
    const val proteinGoal=160
    const val waterGoal=8
    const val walkGoalKm=4.0
    val exercises=listOf("Hammer Curl 3×12", "Bent-over Row 3×12", "Lateral Raise 3×12", "Push-Up 2×16", "Dumbbell Bench Press 3×12")
    fun tasks(day:LocalDate):List<String> = buildList {
        add("Walk 4 km")
        if(day.dayOfWeek in listOf(DayOfWeek.SUNDAY,DayOfWeek.TUESDAY,DayOfWeek.THURSDAY)) addAll(exercises)
        add("Log meals")
        add("Drink 8 glasses of water")
        if(day.dayOfWeek==DayOfWeek.SUNDAY) add("Weekly weigh-in")
    }
    fun today():String=LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
}
