package dev.thutatun.fittrack

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    const val channel="fittrack_reminders"
    fun init(context:Context) {
        val manager=context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(channel,"Fitness reminders",NotificationManager.IMPORTANCE_DEFAULT))
        val request=PeriodicWorkRequestBuilder<ReminderWorker>(15,TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("daily-reminders",ExistingPeriodicWorkPolicy.KEEP,request)
    }
    fun snooze(context:Context,task:String,day:String) {
        val req=OneTimeWorkRequestBuilder<ReminderWorker>().setInitialDelay(5,TimeUnit.MINUTES)
            .setInputData(workDataOf("task" to task,"day" to day)).build()
        WorkManager.getInstance(context).enqueueUniqueWork("snooze-$day-$task",ExistingWorkPolicy.REPLACE,req)
    }
    fun cancel(context:Context,task:String,day:String) {
        WorkManager.getInstance(context).cancelUniqueWork("snooze-$day-$task")
        NotificationManagerCompat.from(context).cancel("$day:$task".hashCode())
    }
}
class ReminderWorker(context:Context,params:WorkerParameters):CoroutineWorker(context,params) {
    override suspend fun doWork():Result {
        val day=Plan.today()
        val requestedDay=inputData.getString("day")
        if(requestedDay!=null && requestedDay!=day) return Result.success()
        val now=LocalTime.now()
        if(now.isBefore(LocalTime.of(8,0))||now.isAfter(LocalTime.of(21,0))) return Result.success()
        val dao=FitDatabase.get(applicationContext).dao()
        val requestedTask=inputData.getString("task")
        val tasks=if(requestedTask!=null) listOf(requestedTask) else buildList {
            if(now.hour in 8..20 && now.minute<15 && now.hour%2==0) add("Drink 8 glasses of water")
            if(now.hour in 18..20) add("Walk 4 km")
            if(now.hour in 18..20) addAll(Plan.tasks(LocalDate.now()).filter { it in Plan.exercises })
            if(now.hour==20) add("Log meals")
            if(LocalDate.now().dayOfWeek==java.time.DayOfWeek.SUNDAY && now.hour==9) add("Weekly weigh-in")
        }
        for(task in tasks.distinct()) {
            if(task !in Plan.tasks(LocalDate.now())) continue
            if(dao.getCheck(day,task)?.done==true) continue
            if(task=="Drink 8 glasses of water" && (dao.getWater(day)?.glasses ?: 0)>=Plan.waterGoal) continue
            show(task,day)
            ReminderScheduler.snooze(applicationContext,task,day)
        }
        return Result.success()
    }
    private fun show(task:String,day:String) {
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(applicationContext,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return
        val id="$day:$task".hashCode()
        fun action(type:String):PendingIntent {
            val intent=Intent(applicationContext,ReminderActionReceiver::class.java).apply {
                putExtra("type",type);putExtra("task",task);putExtra("day",day)
            }
            return PendingIntent.getBroadcast(applicationContext,("$type:$day:$task").hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val notification=NotificationCompat.Builder(applicationContext,ReminderScheduler.channel)
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("FitTrack reminder")
            .setContentText(task).setAutoCancel(true)
            .addAction(0,"Done",action("done")).addAction(0,"Snooze 5 min",action("snooze")).build()
        NotificationManagerCompat.from(applicationContext).notify(id,notification)
    }
}
class ReminderActionReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        val task=intent.getStringExtra("task")?:return
        val day=intent.getStringExtra("day")?:return
        if(intent.getStringExtra("type")=="snooze") {
            ReminderScheduler.snooze(context,task,day)
            NotificationManagerCompat.from(context).cancel("$day:$task".hashCode())
            return
        }
        val pending=goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val dao=FitDatabase.get(context).dao()
                dao.putCheck(CheckEntity(day,task,true))
                if(task=="Drink 8 glasses of water") dao.putWater(WaterEntity(day,Plan.waterGoal))
                ReminderScheduler.cancel(context,task,day)
            } finally { pending.finish() }
        }
    }
}
