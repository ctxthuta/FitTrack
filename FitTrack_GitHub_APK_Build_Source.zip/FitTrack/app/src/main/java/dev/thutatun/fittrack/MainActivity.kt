package dev.thutatun.fittrack

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private val blue=Color(0xFF354CE5)
private val bg=Color(0xFFF5F6FA)
private val text=Color(0xFF121827)
class MainActivity:ComponentActivity() {
    private val dao by lazy { FitDatabase.get(this).dao() }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.init(this)
        setContent {
            val scope=rememberCoroutineScope()
            var tab by remember { mutableStateOf(0) }
            var day by remember { mutableStateOf(LocalDate.now()) }
            val dayKey=day.toString()
            val checks by dao.checks(dayKey).collectAsState(initial=emptyList())
            val weights by dao.weights().collectAsState(initial=emptyList())
            val walks by dao.walk(dayKey).collectAsState(initial=null)
            val meals by dao.meals(dayKey).collectAsState(initial=emptyList())
            val water by dao.water(dayKey).collectAsState(initial=null)
            val allChecks by dao.allChecks().collectAsState(initial=emptyList())
            var key by remember { mutableStateOf("") }
            var showKey by remember { mutableStateOf(false) }
            var weightInput by remember { mutableStateOf("") }
            var kmInput by remember { mutableStateOf("") }
            var stepsInput by remember { mutableStateOf("") }
            var mealName by remember { mutableStateOf("") }
            var mealKcal by remember { mutableStateOf("") }
            var mealProtein by remember { mutableStateOf("") }
            var photoUri by remember { mutableStateOf("") }
            var loading by remember { mutableStateOf(false) }
            var message by remember { mutableStateOf("") }
            val photoPicker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                if(uri!=null) {
                    photoUri=uri.toString()
                    scope.launch {
                        loading=true
                        try {
                            val bytes=contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Unable to read image")
                            val estimate=Gemini.estimate(this@MainActivity,bytes)
                            mealName=estimate.name;mealKcal=estimate.kcal.toString();mealProtein=estimate.protein.toString();message=estimate.note
                        } catch(e:Exception) { message=e.message.orEmpty() }
                        loading=false
                    }
                }
            }
            val notificationPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> message=if(granted) "Notifications enabled" else "Enable notifications in Android Settings" }
            val activityPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> message=if(granted) "Activity permission granted" else "Activity permission denied" }
            val healthPermission=rememberLauncherForActivityResult(androidx.health.connect.client.PermissionController.createRequestPermissionResultContract()) { granted -> message="Health permissions granted: ${granted.size}" }
            MaterialTheme(colorScheme=lightColorScheme(primary=blue,background=bg,surface=Color.White,onSurface=text)) {
                Scaffold(containerColor=bg,bottomBar={ NavigationBar(containerColor=Color.White) {
                    listOf("Home","Calendar","Food","Activity","Progress").forEachIndexed { i,label ->
                        NavigationBarItem(selected=tab==i,onClick={tab=i},icon={ Text(listOf("⌂","▦","◉","◷","↗")[i],fontSize=20.sp) },label={Text(label,fontSize=10.sp)})
                    }
                } }) { padding ->
                    LazyColumn(modifier=Modifier.fillMaxSize().padding(padding),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        item {
                            Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                                Text(listOf("Today","Calendar","Food scanner","Activity","Progress")[tab],fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                                TextButton(onClick={showKey=true}) { Text("Settings") }
                            }
                            if(message.isNotBlank()) Text(message,color=blue,fontSize=12.sp)
                        }
                        if(tab==0 || tab==1) {
                            item { Row(verticalAlignment=Alignment.CenterVertically) {
                                TextButton(onClick={day=day.minusDays(1)}) { Text("‹") }
                                Text(day.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy")),modifier=Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                                TextButton(onClick={day=day.plusDays(1)},enabled=day.isBefore(LocalDate.now())) { Text("›") }
                            } }
                            if(tab==0) {
                                item { Panel { Text("Current weight",color=Color.Gray);Text("${weights.firstOrNull()?.kg ?: "--"} kg",fontSize=35.sp,color=blue,fontWeight=FontWeight.Bold);Text("Goal 80 kg  •  Daily target 1,900 kcal") } }
                                item { Panel { Text("Daily calories",fontWeight=FontWeight.Bold);Text("${meals.sumOf { it.kcal }} / ${Plan.kcalGoal} kcal",fontSize=24.sp,color=blue);LinearProgressIndicator(progress={ (meals.sumOf { it.kcal }.toFloat()/Plan.kcalGoal).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth());Text("Protein: ${meals.sumOf { it.protein }.toInt()} / ${Plan.proteinGoal} g") } }
                                item { Panel { Text("Walking",fontWeight=FontWeight.Bold);Text("${"%.2f".format(walks?.km?:0.0)} / 4 km  •  ${walks?.steps?:0L} steps");LinearProgressIndicator(progress={ ((walks?.km?:0.0)/4.0).toFloat().coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth()) } }
                            }
                            item { Panel {
                                Text(if(tab==1) "Daily history and checklist" else "Daily checklist",fontSize=19.sp,fontWeight=FontWeight.Bold)
                                val tasks=Plan.tasks(day)
                                Text("${tasks.count { t->checks.any { it.task==t&&it.done } }} / ${tasks.size} completed",color=Color.Gray)
                                tasks.forEach { task ->
                                    val checked=checks.any { it.task==task&&it.done }
                                    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                                        Checkbox(checked=checked,onCheckedChange={ value->scope.launch { dao.putCheck(CheckEntity(dayKey,task,value));if(value)ReminderScheduler.cancel(this@MainActivity,task,dayKey) } })
                                        Text(task,modifier=Modifier.weight(1f))
                                    }
                                }
                            } }
                            if(tab==1) item { Panel {
                                Text("Current streak",fontWeight=FontWeight.Bold)
                                val completed=allChecks.groupBy { it.day }.filter { (date,entries)->
                                    val dateObj=runCatching { LocalDate.parse(date) }.getOrNull()
                                    dateObj!=null && Plan.tasks(dateObj).all { task->entries.any { it.task==task&&it.done } }
                                }.keys
                                var streak=0;var cursor=LocalDate.now()
                                if(cursor.toString() !in completed) cursor=cursor.minusDays(1)
                                while(cursor.toString() in completed) { streak++;cursor=cursor.minusDays(1) }
                                Text("$streak days",fontSize=32.sp,color=blue)
                                Text("Missed days stay visible. Resume any day without deleting history.",fontSize=12.sp)
                            } }
                        }
                        if(tab==2) {
                            item { Panel {
                                Text("AI meal analysis",fontSize=19.sp,fontWeight=FontWeight.Bold)
                                Text("Upload a meal photo. Review the estimate before saving.",fontSize=12.sp)
                                Button(onClick={photoPicker.launch("image/*")},enabled=!loading) { Text(if(loading) "Analyzing…" else "Choose food photo") }
                                OutlinedTextField(mealName,{mealName=it},label={Text("Meal name")},modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(mealKcal,{mealKcal=it},label={Text("Estimated calories")},modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(mealProtein,{mealProtein=it},label={Text("Protein (g)")},modifier=Modifier.fillMaxWidth())
                                Button(onClick={ scope.launch {
                                    val kcal=mealKcal.toIntOrNull()
                                    if(mealName.isNotBlank()&&kcal!=null&&kcal>=0) {
                                        dao.putMeal(MealEntity(day=dayKey,name=mealName,kcal=kcal,protein=mealProtein.toDoubleOrNull()?:0.0,photoUri=photoUri))
                                        mealName="";mealKcal="";mealProtein="";photoUri="";message="Meal saved"
                                    } else message="Enter a meal name and valid calories"
                                } }) { Text("Confirm and save meal") }
                            } }
                            items(meals) { meal -> Panel { Text(meal.name,fontWeight=FontWeight.Bold);Text("${meal.kcal} kcal  •  ${meal.protein} g protein") } }
                        }
                        if(tab==3) {
                            item { Panel {
                                Text("Walking and steps",fontSize=19.sp,fontWeight=FontWeight.Bold)
                                Text("Recorded: ${walks?.km?:0.0} km, ${walks?.steps?:0} steps")
                                OutlinedTextField(kmInput,{kmInput=it},label={Text("Distance (km)")},modifier=Modifier.fillMaxWidth())
                                OutlinedTextField(stepsInput,{stepsInput=it},label={Text("Steps")},modifier=Modifier.fillMaxWidth())
                                Button(onClick={scope.launch {
                                    val km=kmInput.toDoubleOrNull()
                                    if(km!=null&&km>=0) { dao.putWalk(WalkEntity(dayKey,km,stepsInput.toLongOrNull()?:0));message="Walk saved" }
                                }}) { Text("Save activity") }
                                HorizontalDivider()
                                Button(onClick={ if(Health.available(this@MainActivity)) healthPermission.launch(Health.permissions) else message="Health Connect unavailable on this device" }) { Text("Grant Health Connect access") }
                                OutlinedButton(onClick={scope.launch {
                                    try {
                                        val (steps,km)=Health.readDay(this@MainActivity,day)
                                        dao.putWalk(WalkEntity(dayKey,km,steps,"health_connect"))
                                        message="Health Connect data imported"
                                    } catch(e:Exception) {message=e.message.orEmpty()}
                                }}) { Text("Import steps and distance") }
                                Text("Health Connect import replaces this day's walk entry to avoid double counting. Manual and imported distances are not added together.",fontSize=12.sp)
                            } }
                            item { Panel {
                                Text("Water",fontSize=19.sp,fontWeight=FontWeight.Bold)
                                Text("${water?.glasses?:0} / ${Plan.waterGoal} glasses")
                                Row { Button(onClick={scope.launch { val count=((water?.glasses?:0)+1);dao.putWater(WaterEntity(dayKey,count));if(count>=Plan.waterGoal){dao.putCheck(CheckEntity(dayKey,"Drink 8 glasses of water",true));ReminderScheduler.cancel(this@MainActivity,"Drink 8 glasses of water",dayKey)} }}) {Text("+ 1 glass")}; Spacer(Modifier.width(8.dp));OutlinedButton(onClick={scope.launch {dao.putWater(WaterEntity(dayKey,0));dao.putCheck(CheckEntity(dayKey,"Drink 8 glasses of water",false))}}) {Text("Reset")}}
                            } }
                        }
                        if(tab==4) {
                            item { Panel {
                                Text("Weekly weigh-in",fontSize=19.sp,fontWeight=FontWeight.Bold)
                                OutlinedTextField(weightInput,{weightInput=it},label={Text("Weight (kg)")},modifier=Modifier.fillMaxWidth())
                                Button(onClick={scope.launch {
                                    val kg=weightInput.toDoubleOrNull()
                                    if(kg!=null&&kg in 20.0..500.0) {
                                        dao.putWeight(WeightEntity(dayKey,kg));weightInput="";message="Weight saved locally"
                                        try { Health.writeWeight(this@MainActivity,day,kg);dao.putWeight(WeightEntity(dayKey,kg,true));message="Weight saved and synced" } catch(_:Exception) { message="Weight saved locally. Grant Health Connect access to sync." }
                                    }
                                }}) {Text("Save weight")}
                                Text("Records are keyed by date, so saving the same day updates instead of duplicating.",fontSize=12.sp)
                            } }
                            item { Panel {
                                Text("Weight history",fontSize=19.sp,fontWeight=FontWeight.Bold)
                                weights.take(20).forEach { w->Row(modifier=Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(w.day);Text("${w.kg} kg") } }
                                if(weights.size>1) Text("Change: ${"%.1f".format(weights.first().kg-weights.last().kg)} kg",color=blue)
                            } }
                            item { Panel {
                                Text("Progress summary",fontWeight=FontWeight.Bold)
                                Text("Daily tasks: ${allChecks.count { it.done }} completed records")
                                Text("Review weight trends and calendar completion to measure progress.")
                            } }
                        }
                        item { Spacer(Modifier.height(12.dp)) }
                    }
                }
                if(showKey) AlertDialog(onDismissRequest={showKey=false},title={Text("Settings and reminders")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(key,{key=it},label={Text("Gemini API key")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={SecretStore.save(this@MainActivity,key);key="";message="API key stored on device";showKey=false}) {Text("Save Gemini key")}
                    if(Build.VERSION.SDK_INT>=33) OutlinedButton(onClick={notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)}) {Text("Enable notifications")}
                    OutlinedButton(onClick={activityPermission.launch(Manifest.permission.ACTIVITY_RECOGNITION)}) {Text("Allow activity recognition")}
                    Text("Reminders run 08:00–21:00. Unchecked tasks repeat after approximately five minutes, subject to Android background scheduling.",fontSize=12.sp)
                }},confirmButton={TextButton(onClick={showKey=false}) {Text("Close")}})
            }
        }
    }
}
@Composable private fun Panel(content:@Composable ColumnScope.()->Unit) {
    Surface(shape=RoundedCornerShape(18.dp),color=Color.White,modifier=Modifier.fillMaxWidth()) {
        Column(modifier=Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content)
    }
}
